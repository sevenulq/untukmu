# Kado
-Flower code from: https://codepen.io/mdusmanansari/pen/BamepLe


# Description
Flower code tiktok trend 

Responsive Web -- bisa langsung disesuikan di file css --> style.css


Thanks to codepan and mdusmanansari
